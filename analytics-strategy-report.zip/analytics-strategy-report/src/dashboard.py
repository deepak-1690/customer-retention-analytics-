"""Interactive churn-insights dashboard (Plotly Dash).

Run:  python src/analysis.py && python src/dashboard.py
Open: http://127.0.0.1:8050

Storytelling layout: KPIs -> where is the problem -> why -> who to act on.
"""
from pathlib import Path
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html, dash_table

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "processed" / "customers_scored.csv")
monthly = pd.read_csv(ROOT / "data" / "raw" / "monthly.csv")
drivers = pd.read_csv(ROOT / "data" / "processed" / "drivers.csv")

PALETTE = {"Low": "#2a9d8f", "Medium": "#e9c46a", "High": "#e76f51"}
LABELS = {"days_since_last_order": "Days since last order", "support_tickets": "Support tickets",
          "tenure_months": "Tenure (months)", "email_open_rate": "Email open rate",
          "avg_order_value": "Avg order value", "orders_12m": "Orders (12m)",
          "discount_share": "Discount share"}

app = Dash(__name__, title="Customer Retention Insights")


def kpi(title, value_id):
    return html.Div([html.Div(title, className="kpi-title"),
                     html.Div(id=value_id, className="kpi-value")],
                    style={"flex": 1, "padding": "12px 16px", "background": "#f4f6f8",
                           "borderRadius": 8})


app.layout = html.Div(style={"fontFamily": "Segoe UI, Arial", "maxWidth": 1200,
                             "margin": "0 auto", "padding": 16}, children=[
    html.H2("Customer Retention Insights"),
    html.P("Filter the view, then click bars to drill into a segment.",
           style={"color": "#555"}),
    html.Div([
        dcc.Dropdown(sorted(df.region.unique()), multi=True, id="region",
                     placeholder="All regions", style={"flex": 1}),
        dcc.Dropdown(sorted(df.segment.unique()), multi=True, id="segment",
                     placeholder="All segments", style={"flex": 1}),
    ], style={"display": "flex", "gap": 12, "marginBottom": 12}),
    html.Div([kpi("Customers", "k-cust"), kpi("Churn rate", "k-churn"),
              kpi("Revenue (12m)", "k-rev"), kpi("Active revenue at high risk", "k-risk")],
             style={"display": "flex", "gap": 12, "marginBottom": 12}),
    html.Div([dcc.Graph(id="seg-bar", style={"flex": 1}),
              dcc.Graph(id="recency-line", style={"flex": 1})],
             style={"display": "flex"}),
    html.Div([dcc.Graph(id="driver-bar", style={"flex": 1}),
              dcc.Graph(id="rev-trend", style={"flex": 1})],
             style={"display": "flex"}),
    html.H4("Priority outreach list (highest risk, still active)"),
    dash_table.DataTable(id="table", page_size=10, sort_action="native",
                         style_header={"fontWeight": "bold"}),
])


def filt(regions, segments):
    d = df
    if regions:
        d = d[d.region.isin(regions)]
    if segments:
        d = d[d.segment.isin(segments)]
    return d


@app.callback(
    Output("k-cust", "children"), Output("k-churn", "children"),
    Output("k-rev", "children"), Output("k-risk", "children"),
    Output("seg-bar", "figure"), Output("recency-line", "figure"),
    Output("driver-bar", "figure"), Output("rev-trend", "figure"),
    Output("table", "data"), Output("table", "columns"),
    Input("region", "value"), Input("segment", "value"),
    Input("seg-bar", "clickData"))
def update(regions, segments, click):
    d = filt(regions, segments)
    if click:  # drill-down: clicking a segment bar narrows the table
        d_tbl = d[d.segment == click["points"][0]["x"]]
    else:
        d_tbl = d
    active_high = d[(d.risk_tier == "High") & (d.churned == 0)]

    seg = d.groupby("segment", as_index=False).churned.mean()
    f1 = px.bar(seg, x="segment", y="churned", title="Churn rate by segment",
                labels={"churned": "Churn rate"}, text_auto=".0%")
    f1.update_yaxes(tickformat=".0%")

    rec = d.groupby("recency_band", observed=True, as_index=False).churned.mean()
    f2 = px.line(rec, x="recency_band", y="churned", markers=True,
                 title="Churn climbs with days since last order",
                 labels={"recency_band": "Days since last order", "churned": "Churn rate"})
    f2.update_yaxes(tickformat=".0%")

    dr = drivers.assign(label=drivers.feature.map(LABELS),
                        effect=drivers.coefficient.map(lambda c: "Raises churn" if c > 0 else "Lowers churn"))
    f3 = px.bar(dr.sort_values("coefficient"), x="coefficient", y="label", orientation="h",
                color="effect", title="What drives churn (standardised coefficients)",
                color_discrete_map={"Raises churn": "#e76f51", "Lowers churn": "#2a9d8f"},
                labels={"label": "", "coefficient": "Effect on churn (log-odds)"})

    f4 = px.area(monthly, x="month", y="revenue_k", title="Monthly revenue ($k)",
                 labels={"revenue_k": "Revenue ($k)", "month": ""})
    f4.update_xaxes(rangeslider_visible=True)  # interactive time zoom

    top = (d_tbl[d_tbl.churned == 0].sort_values("churn_risk", ascending=False)
           .head(50)[["customer_id", "segment", "region", "churn_risk", "revenue_12m"]]
           .assign(churn_risk=lambda x: x.churn_risk.round(2)))
    cols = [{"name": c.replace("_", " ").title(), "id": c} for c in top.columns]

    return (f"{len(d):,}", f"{d.churned.mean():.1%}", f"${d.revenue_12m.sum():,.0f}",
            f"${active_high.revenue_12m.sum():,.0f}", f1, f2, f3, f4,
            top.to_dict("records"), cols)


if __name__ == "__main__":
    app.run(debug=True)
