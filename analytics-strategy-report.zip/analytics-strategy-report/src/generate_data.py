"""Generate a synthetic e-commerce customer dataset.

REPLACE THIS FILE'S OUTPUT with your own project data: save your cleaned
dataset to data/raw/customers.csv using the same column names (or adapt
analysis.py and dashboard.py to your columns).
"""
from pathlib import Path
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 5000
OUT = Path(__file__).resolve().parents[1] / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)

region = rng.choice(["North", "South", "East", "West"], N, p=[.28, .24, .26, .22])
segment = rng.choice(["Budget", "Standard", "Premium"], N, p=[.38, .42, .20])
tenure = rng.integers(1, 61, N)
orders = rng.poisson(lam=np.where(segment == "Premium", 14, np.where(segment == "Standard", 8, 4)))
aov = np.round(rng.normal(np.where(segment == "Premium", 95, np.where(segment == "Standard", 55, 28)), 9).clip(8), 2)
tickets = rng.poisson(lam=1.2, size=N)
discount_share = np.round(rng.beta(2, 5, N), 2)
days_since_last = rng.integers(1, 181, N)
email_open_rate = np.round(rng.beta(3, 4, N), 2)

logit = (-1.6 + 0.45 * tickets + 0.012 * days_since_last - 0.03 * tenure
         - 0.06 * orders - 1.4 * email_open_rate + 1.0 * discount_share
         + np.where(segment == "Budget", 0.5, 0) + np.where(region == "South", 0.25, 0))
churned = (rng.random(N) < 1 / (1 + np.exp(-logit))).astype(int)

df = pd.DataFrame(dict(
    customer_id=np.arange(1, N + 1), region=region, segment=segment,
    tenure_months=tenure, orders_12m=orders, avg_order_value=aov,
    support_tickets=tickets, discount_share=discount_share,
    days_since_last_order=days_since_last, email_open_rate=email_open_rate,
    churned=churned))
df["revenue_12m"] = (df.orders_12m * df.avg_order_value).round(2)
df.to_csv(OUT / "customers.csv", index=False)

months = pd.period_range("2025-01", periods=12, freq="M").astype(str)
base = np.linspace(410, 520, 12) + rng.normal(0, 12, 12)
monthly = pd.DataFrame({"month": months, "revenue_k": base.round(1),
                        "active_customers": np.linspace(3900, 4300, 12).astype(int)})
monthly.to_csv(OUT / "monthly.csv", index=False)
print(f"Wrote {len(df)} customers; churn rate {df.churned.mean():.1%}")
