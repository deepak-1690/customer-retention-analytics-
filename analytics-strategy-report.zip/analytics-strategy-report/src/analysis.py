"""Descriptive + predictive analysis. Writes tidy tables to data/processed/."""
from pathlib import Path
import json
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
RAW, PROC = ROOT / "data" / "raw", ROOT / "data" / "processed"
PROC.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(RAW / "customers.csv")

# 1) Descriptive summaries ---------------------------------------------------
by_segment = df.groupby("segment").agg(customers=("customer_id", "count"),
    churn_rate=("churned", "mean"), revenue=("revenue_12m", "sum")).reset_index()
by_region = df.groupby("region").agg(customers=("customer_id", "count"),
    churn_rate=("churned", "mean")).reset_index()
df["ticket_band"] = pd.cut(df.support_tickets, [-1, 0, 2, 100], labels=["0", "1-2", "3+"])
by_tickets = df.groupby("ticket_band", observed=True).churned.mean().reset_index()
df["recency_band"] = pd.cut(df.days_since_last_order, [0, 30, 60, 90, 180],
                            labels=["0-30", "31-60", "61-90", "91-180"])
by_recency = df.groupby("recency_band", observed=True).churned.mean().reset_index()

# 2) Predictive model --------------------------------------------------------
features = ["tenure_months", "orders_12m", "avg_order_value", "support_tickets",
            "discount_share", "days_since_last_order", "email_open_rate"]
X, y = df[features], df.churned
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.25, random_state=42, stratify=y)
sc = StandardScaler().fit(Xtr)
model = LogisticRegression(max_iter=1000).fit(sc.transform(Xtr), ytr)
auc = roc_auc_score(yte, model.predict_proba(sc.transform(Xte))[:, 1])
drivers = pd.DataFrame({"feature": features, "coefficient": model.coef_[0]}) \
    .sort_values("coefficient", key=abs, ascending=False)

# 3) Risk scoring + revenue at risk -----------------------------------------
df["churn_risk"] = model.predict_proba(sc.transform(X))[:, 1]
df["risk_tier"] = pd.cut(df.churn_risk, [0, .2, .4, 1], labels=["Low", "Medium", "High"])
at_risk = df[(df.risk_tier == "High") & (df.churned == 0)]

summary = dict(customers=int(len(df)), churn_rate=float(df.churned.mean()),
    revenue_12m=float(df.revenue_12m.sum()), auc=float(auc),
    high_risk_active=int(len(at_risk)),
    revenue_at_risk=float(at_risk.revenue_12m.sum()))

by_segment.to_csv(PROC / "by_segment.csv", index=False)
by_region.to_csv(PROC / "by_region.csv", index=False)
by_tickets.to_csv(PROC / "by_tickets.csv", index=False)
by_recency.to_csv(PROC / "by_recency.csv", index=False)
drivers.to_csv(PROC / "drivers.csv", index=False)
df.to_csv(PROC / "customers_scored.csv", index=False)
(PROC / "summary.json").write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2)); print(by_segment); print(by_region)
print(by_tickets); print(by_recency); print(drivers)
