"""Export static PNGs of the key storytelling charts for the report/slides.
Requires plotly + kaleido. Output: assets/exports/
"""
from pathlib import Path
import pandas as pd
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / "data" / "processed"
OUT = ROOT / "assets" / "exports"
OUT.mkdir(parents=True, exist_ok=True)

seg = pd.read_csv(P / "by_segment.csv")
px.bar(seg, x="segment", y="churn_rate", text_auto=".0%",
       title="Budget customers churn at more than twice the Premium rate"
       ).update_yaxes(tickformat=".0%").write_image(OUT / "churn_by_segment.png", scale=2)

rec = pd.read_csv(P / "by_recency.csv")
px.line(rec, x="recency_band", y="churn_rate" if "churn_rate" in rec else "churned",
        markers=True, title="Churn rises sharply after 90 days of inactivity"
        ).update_yaxes(tickformat=".0%").write_image(OUT / "churn_by_recency.png", scale=2)

drv = pd.read_csv(P / "drivers.csv")
px.bar(drv.sort_values("coefficient"), x="coefficient", y="feature", orientation="h",
       title="Drivers of churn").write_image(OUT / "drivers.png", scale=2)
print("Saved charts to", OUT)
