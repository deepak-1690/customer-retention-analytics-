# Customer Retention Analytics: Strategic Report & Dashboard

Final-week deliverable for a data analytics project: a strategic report and presentation
storyboard (Word), plus the Python code that produces the insights and an interactive
Plotly Dash dashboard.

## What's inside
| Path | Purpose |
|---|---|
| `docs/Strategic_Report_and_Storyboard.docx` | The report: executive summary, findings, recommendations, visualisation plan, presentation storyboard, audience strategy |
| `src/generate_data.py` | Creates a reproducible synthetic dataset (replace with your own data) |
| `src/analysis.py` | Segmentation, logistic-regression churn model, risk tiers |
| `src/dashboard.py` | Interactive Dash dashboard (filters, drill-down, range slider, priority table) |
| `src/make_charts.py` | Exports static PNG charts for slides |
| `data/raw`, `data/processed` | Inputs and generated outputs |

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python src/generate_data.py      # or put your own data in data/raw/customers.csv
python src/analysis.py
python src/dashboard.py          # http://127.0.0.1:8050
python src/make_charts.py        # optional static charts
```

## Use your own project data
Provide `data/raw/customers.csv` with columns: `customer_id, region, segment, tenure_months,
orders_12m, avg_order_value, support_tickets, discount_share, days_since_last_order,
email_open_rate, churned, revenue_12m` and a `data/raw/monthly.csv` with
`month, revenue_k, active_customers`. Or edit the column lists in `analysis.py` and `dashboard.py`.
Then update the numbers in the report to match your outputs (`data/processed/summary.json`).

## Headline results (synthetic data)
- 5,000 customers, 24.5% churn, $2.44M 12-month revenue
- Budget churn 34.6% vs Premium 15.3%; 3+ support tickets -> 44.4% churn
- Model AUC 0.76; 454 active high-risk customers = $128.5K revenue at risk

## License
MIT
